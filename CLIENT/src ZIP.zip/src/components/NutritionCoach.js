import React, { useState, useRef, useEffect } from "react";

const WELCOME = `👋 Hello! I'm **NutriCoach**, your AI-powered nutrition guide. I'm here to help you make informed dietary choices, answer your nutrition questions, and support your wellness journey.

What nutrition topic can I help you with today?`;

const QUICK_QUESTIONS = [
  "How much protein do I need daily?",
  "What foods boost energy levels?",
  "Best foods for weight loss?",
  "How to reduce sugar cravings?",
  "Tips for meal prepping?",
  "What are superfoods?",
];

export default function NutritionCoach() {
  const [messages, setMessages] = useState([{ role: "coach", content: WELCOME }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const sendMessage = async (text = input) => {
    const msg = text.trim();
    if (!msg || loading) return;
    const userMsg = { role: "user", content: msg };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput("");
    setLoading(true);

    try {
      const history = updatedMessages
        .filter((m) => m.role !== "coach" || m.content !== WELCOME)
        .map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.content }));

      const res = await fetch("/api/coach/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: msg, history: history.slice(-10) }),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error);
      setMessages((m) => [...m, { role: "coach", content: data.response }]);
    } catch (err) {
      setMessages((m) => [...m, { role: "coach", content: `I apologize, I encountered an error. Please try again. (${err.message})` }]);
    }
    setLoading(false);
  };

  const formatMsg = (text) => {
    // Very simple markdown: bold
    return text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
  };

  return (
    <div>
      <h1 className="page-title">🤖 Virtual Nutrition Coach</h1>
      <p className="page-subtitle">Get personalized, evidence-based nutrition guidance from your AI coach — available 24/7.</p>

      <div className="coach-container">
        {/* Coach Profile */}
        <div className="card" style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20, padding: "16px 24px" }}>
          <div style={{ width: 52, height: 52, borderRadius: "50%", background: "var(--green-700)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>🌿</div>
          <div>
            <p style={{ fontFamily: "'Playfair Display', serif", fontSize: 18, fontWeight: 600, color: "var(--green-900)" }}>NutriCoach AI</p>
            <p style={{ fontSize: 13, color: "var(--text-muted)" }}>Certified Nutrition Specialist • Powered by Google Gemini</p>
          </div>
          <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 9, height: 9, borderRadius: "50%", background: "#22a052" }} />
            <span style={{ fontSize: 12, color: "var(--green-600)", fontWeight: 600 }}>Online</span>
          </div>
        </div>

        {/* Quick Questions */}
        <div className="quick-questions">
          {QUICK_QUESTIONS.map((q) => (
            <button key={q} className="quick-q" onClick={() => sendMessage(q)}>{q}</button>
          ))}
        </div>

        {/* Chat Window */}
        <div className="chat-window">
          {messages.map((msg, i) => (
            <div key={i} className={`chat-bubble ${msg.role}`}>
              <div dangerouslySetInnerHTML={{ __html: formatMsg(msg.content).replace(/\n/g, "<br/>") }} />
            </div>
          ))}
          {loading && (
            <div className="chat-bubble coach" style={{ opacity: 0.7 }}>
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                <div className="spinner" style={{ width: 18, height: 18, borderWidth: 2 }} />
                <span style={{ fontSize: 13 }}>NutriCoach is thinking…</span>
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        {/* Input */}
        <div className="chat-input-row">
          <input
            className="form-input"
            placeholder="Ask me anything about nutrition…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
            disabled={loading}
          />
          <button className="btn btn-primary" onClick={() => sendMessage()} disabled={loading || !input.trim()}>
            Send →
          </button>
        </div>

        <p style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 10, textAlign: "center" }}>
          NutriCoach provides general nutrition information. Always consult a registered dietitian for medical nutrition therapy.
        </p>
      </div>
    </div>
  );
}
