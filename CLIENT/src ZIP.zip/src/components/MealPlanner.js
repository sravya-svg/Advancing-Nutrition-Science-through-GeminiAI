import React, { useState } from "react";

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export default function MealPlanner() {
  const [form, setForm] = useState({
    dietaryRestrictions: "", allergies: "", healthConditions: "",
    activityLevel: "Moderate", preferences: "", calorieTarget: "2000", goal: "Maintain healthy weight",
  });
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState(null);
  const [error, setError] = useState("");
  const [activeDay, setActiveDay] = useState(0);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const generate = async () => {
    setLoading(true); setError(""); setPlan(null);
    try {
      const res = await fetch("/api/meal-plan/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error);
      setPlan(data.data);
    } catch (err) {
      setError(err.message || "Failed to generate meal plan.");
    }
    setLoading(false);
  };

  return (
    <div>
      <h1 className="page-title">📅 Personalized Meal Planner</h1>
      <p className="page-subtitle">Get a complete 7-day meal plan tailored to your unique needs and preferences.</p>

      {!plan ? (
        <div className="card planner-form">
          {error && <div className="error-msg">⚠️ {error}</div>}
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Dietary Restrictions</label>
              <input className="form-input" placeholder="Vegan, Gluten-free, Halal…" value={form.dietaryRestrictions} onChange={set("dietaryRestrictions")} />
            </div>
            <div className="form-group">
              <label className="form-label">Allergies</label>
              <input className="form-input" placeholder="Nuts, Dairy, Shellfish…" value={form.allergies} onChange={set("allergies")} />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Health Conditions</label>
              <input className="form-input" placeholder="Diabetes, Hypertension…" value={form.healthConditions} onChange={set("healthConditions")} />
            </div>
            <div className="form-group">
              <label className="form-label">Activity Level</label>
              <select className="form-select" value={form.activityLevel} onChange={set("activityLevel")}>
                {["Sedentary", "Light", "Moderate", "Active", "Very Active"].map((a) => <option key={a}>{a}</option>)}
              </select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Daily Calorie Target</label>
              <input className="form-input" type="number" placeholder="2000" value={form.calorieTarget} onChange={set("calorieTarget")} />
            </div>
            <div className="form-group">
              <label className="form-label">Goal</label>
              <select className="form-select" value={form.goal} onChange={set("goal")}>
                {["Lose weight", "Maintain healthy weight", "Gain muscle", "Improve energy", "Manage health condition"].map((g) => <option key={g}>{g}</option>)}
              </select>
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Food Preferences & Dislikes</label>
            <textarea className="form-textarea" placeholder="I love Mediterranean food, hate mushrooms, prefer quick meals…" value={form.preferences} onChange={set("preferences")} />
          </div>
          <button className="btn btn-primary" onClick={generate} disabled={loading} style={{ width: "100%", marginTop: 8 }}>
            {loading ? "Crafting your plan…" : "✨ Generate My Meal Plan"}
          </button>
        </div>
      ) : (
        <div className="nutrition-result">
          {/* Summary Banner */}
          <div className="card" style={{ marginBottom: 24, display: "flex", flexWrap: "wrap", gap: 28, alignItems: "center" }}>
            <div>
              <p className="form-label">Weekly Average</p>
              <p style={{ fontSize: 28, fontWeight: 700, color: "var(--green-700)" }}>{plan.nutritionSummary?.avgDailyCalories} kcal/day</p>
            </div>
            {["avgProtein", "avgCarbs", "avgFat"].map((k) => (
              <div key={k}>
                <p className="form-label">{k.replace("avg", "")}</p>
                <p style={{ fontSize: 20, fontWeight: 700, color: "var(--green-800)" }}>{plan.nutritionSummary?.[k]}</p>
              </div>
            ))}
            <button className="btn btn-secondary" style={{ marginLeft: "auto" }} onClick={() => setPlan(null)}>← New Plan</button>
          </div>

          {/* Day Selector */}
          <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
            {plan.weeklyPlan?.map((day, i) => (
              <button key={i} className={`btn ${activeDay === i ? "btn-primary" : "btn-secondary"}`}
                style={{ padding: "8px 16px", fontSize: 13 }} onClick={() => setActiveDay(i)}>
                {day.day?.slice(0, 3)}
              </button>
            ))}
          </div>

          {/* Active Day Detail */}
          {plan.weeklyPlan?.[activeDay] && (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 16, marginBottom: 28 }}>
              {["breakfast", "lunch", "dinner"].map((mealType) => {
                const meal = plan.weeklyPlan[activeDay].meals?.[mealType];
                if (!meal) return null;
                return (
                  <div className="card" key={mealType}>
                    <p className="meal-type">{mealType} · {meal.calories} kcal · ⏱ {meal.prepTime}</p>
                    <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 17, marginBottom: 10 }}>{meal.name}</h3>
                    <div style={{ marginBottom: 10 }}>
                      {meal.ingredients?.map((ing, i) => (
                        <span key={i} className="tag tag-green" style={{ marginRight: 4, marginBottom: 4 }}>{ing}</span>
                      ))}
                    </div>
                    {meal.recipe && (
                      <details>
                        <summary style={{ fontSize: 13, color: "var(--green-600)", cursor: "pointer", fontWeight: 600 }}>View Recipe Steps</summary>
                        <p style={{ fontSize: 13, color: "var(--text-muted)", marginTop: 8, lineHeight: 1.6 }}>{meal.recipe}</p>
                      </details>
                    )}
                  </div>
                );
              })}
              {/* Snacks */}
              {plan.weeklyPlan[activeDay].meals?.snacks?.length > 0 && (
                <div className="card">
                  <p className="meal-type">Snacks</p>
                  {plan.weeklyPlan[activeDay].meals.snacks.map((s, i) => (
                    <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid var(--green-50)", fontSize: 14 }}>
                      <span>{s.name}</span><span style={{ color: "var(--green-600)" }}>{s.calories} kcal</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Grocery List */}
          {plan.groceryList && (
            <div className="card">
              <h3 className="section-title">🛒 Weekly Grocery List</h3>
              <div className="grocery-grid">
                {Object.entries(plan.groceryList).map(([category, items]) => (
                  <div className="grocery-category" key={category}>
                    <p className="grocery-cat-title">{category}</p>
                    {items?.map((item, i) => <div className="grocery-item" key={i}>{item}</div>)}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tips */}
          {plan.tips?.length > 0 && (
            <div className="card" style={{ marginTop: 20, background: "var(--green-50)", borderColor: "var(--green-100)" }}>
              <h3 className="section-title">💡 Nutrition Tips</h3>
              {plan.tips.map((tip, i) => (
                <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10, fontSize: 14 }}>
                  <span style={{ color: "var(--green-500)", fontWeight: 700 }}>0{i + 1}</span>
                  <p>{tip}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {loading && (
        <div className="loading" style={{ marginTop: 40 }}>
          <div className="spinner" />
          Crafting your personalized 7-day meal plan with Gemini AI…
        </div>
      )}
    </div>
  );
}
