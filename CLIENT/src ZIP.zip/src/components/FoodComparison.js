import React, { useState } from "react";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from "recharts";

const PRESETS = [
  ["Brown Rice", "White Rice", "Quinoa"],
  ["Chicken Breast", "Salmon", "Tofu"],
  ["Avocado", "Olive Oil", "Butter"],
  ["Apple", "Banana", "Orange"],
];

export default function FoodComparison() {
  const [foods, setFoods] = useState(["", "", ""]);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState("");

  const updateFood = (i, val) => setFoods((f) => { const n = [...f]; n[i] = val; return n; });

  const compare = async (foodList = foods) => {
    const filtered = foodList.filter((f) => f.trim());
    if (filtered.length < 2) return;
    setLoading(true); setError(""); setResults(null);
    try {
      const res = await fetch("/api/nutrition/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ foods: filtered }),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error);
      setResults(data.data);
    } catch (err) {
      setError(err.message || "Failed to compare foods.");
    }
    setLoading(false);
  };

  const COLORS = ["#22a052", "#f5a623", "#3b82f6", "#e53e3e"];

  const radarData = results
    ? ["protein", "carbs", "fat", "fiber"].map((key) => ({
        subject: key.charAt(0).toUpperCase() + key.slice(1),
        ...results.reduce((acc, r) => ({ ...acc, [r.food]: r[key] }), {}),
      }))
    : [];

  return (
    <div>
      <h1 className="page-title">⚖️ Food Comparison</h1>
      <p className="page-subtitle">Compare the nutritional profiles of multiple foods side by side.</p>

      <div className="card" style={{ marginBottom: 28 }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 16 }}>
          {foods.map((f, i) => (
            <div key={i} className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">Food {i + 1}{i < 2 ? " *" : ""}</label>
              <input className="form-input" placeholder={`e.g., ${["Apple", "Banana", "Orange"][i]}`}
                value={f} onChange={(e) => updateFood(i, e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && compare()} />
            </div>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 16 }}>
          <span className="form-label" style={{ alignSelf: "center" }}>Quick Compare:</span>
          {PRESETS.map((preset) => (
            <button key={preset.join()} className="quick-q" onClick={() => {
              setFoods([...preset, ""].slice(0, 3));
              compare(preset);
            }}>
              {preset.join(" vs ")}
            </button>
          ))}
        </div>

        <button className="btn btn-primary" onClick={() => compare()} disabled={loading || foods.filter((f) => f.trim()).length < 2}>
          {loading ? "Comparing…" : "Compare Now"}
        </button>
      </div>

      {error && <div className="error-msg">⚠️ {error}</div>}
      {loading && (
        <div className="loading">
          <div className="spinner" />
          Comparing nutritional profiles with Gemini AI…
        </div>
      )}

      {results && (
        <div className="nutrition-result">
          {/* Cards */}
          <div className="compare-results" style={{ marginBottom: 32 }}>
            {results.map((item, i) => (
              <div className="compare-card" key={i} style={{ borderTop: `4px solid ${COLORS[i]}` }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
                  <h3 className="compare-food-name">{item.food}</h3>
                  <div className="score-circle" style={{ width: 44, height: 44, borderWidth: 3, borderColor: COLORS[i] }}>
                    <span style={{ fontSize: 14, fontWeight: 700, color: COLORS[i] }}>{item.healthScore}</span>
                  </div>
                </div>
                {[
                  ["Calories", item.calories + " kcal"],
                  ["Protein", item.protein + "g"],
                  ["Carbs", item.carbs + "g"],
                  ["Fat", item.fat + "g"],
                  ["Fiber", item.fiber + "g"],
                ].map(([name, val]) => (
                  <div className="compare-stat" key={name}>
                    <span className="stat-name">{name}</span>
                    <span className="stat-val">{val}</span>
                  </div>
                ))}
                <div style={{ marginTop: 12 }}>
                  <span className="tag tag-green">{item.bestFor}</span>
                </div>
                <p style={{ fontSize: 13, color: "var(--text-muted)", marginTop: 10 }}>{item.highlight}</p>
              </div>
            ))}
          </div>

          {/* Bar Chart */}
          <div className="card" style={{ marginBottom: 24 }}>
            <h3 className="section-title">Macronutrient Comparison (per serving)</h3>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={[
                { name: "Calories", ...results.reduce((a, r) => ({ ...a, [r.food]: r.calories }), {}) },
                { name: "Protein (g)", ...results.reduce((a, r) => ({ ...a, [r.food]: r.protein }), {}) },
                { name: "Carbs (g)", ...results.reduce((a, r) => ({ ...a, [r.food]: r.carbs }), {}) },
                { name: "Fat (g)", ...results.reduce((a, r) => ({ ...a, [r.food]: r.fat }), {}) },
              ]}>
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                {results.map((r, i) => (
                  <Bar key={r.food} dataKey={r.food} fill={COLORS[i]} radius={[4, 4, 0, 0]} />
                ))}
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Radar Chart */}
          <div className="card">
            <h3 className="section-title">Nutritional Balance Overview</h3>
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={radarData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 13 }} />
                {results.map((r, i) => (
                  <Radar key={r.food} name={r.food} dataKey={r.food} stroke={COLORS[i]} fill={COLORS[i]} fillOpacity={0.15} />
                ))}
                <Legend />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
