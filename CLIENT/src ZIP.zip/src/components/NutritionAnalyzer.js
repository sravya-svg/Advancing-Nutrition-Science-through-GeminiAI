import React, { useState } from "react";

const EXAMPLE_FOODS = ["Brown Rice (1 cup)", "Avocado", "Chicken Breast (100g)", "Blueberries", "Greek Yogurt"];

export default function NutritionAnalyzer() {
  const [foodItem, setFoodItem] = useState("");
  const [quantity, setQuantity] = useState("");
  const [unit, setUnit] = useState("serving");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const analyze = async (food = foodItem) => {
    if (!food.trim()) return;
    setLoading(true); setError(""); setResult(null);
    try {
      const res = await fetch("/api/nutrition/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ foodItem: food, quantity, unit }),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error);
      setResult(data.data);
    } catch (err) {
      setError(err.message || "Failed to analyze. Please try again.");
    }
    setLoading(false);
  };

  const scoreColor = (score) => {
    if (score >= 8) return "#22a052";
    if (score >= 5) return "#f5a623";
    return "#e53e3e";
  };

  return (
    <div>
      <h1 className="page-title">🔬 Nutrition Analyzer</h1>
      <p className="page-subtitle">Instantly get detailed nutritional data for any food item, powered by Gemini AI.</p>

      <div className="analyzer-grid">
        {/* Left Panel */}
        <div>
          <div className="card">
            <div className="form-group">
              <label className="form-label">Food Item</label>
              <input
                className="form-input"
                placeholder="e.g., Salmon, Apple, Brown Rice..."
                value={foodItem}
                onChange={(e) => setFoodItem(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && analyze()}
              />
            </div>
            <div className="form-row" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
              <div className="form-group" style={{ marginBottom: 0 }}>
                <label className="form-label">Quantity</label>
                <input className="form-input" placeholder="1" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
              </div>
              <div className="form-group" style={{ marginBottom: 0 }}>
                <label className="form-label">Unit</label>
                <select className="form-select" value={unit} onChange={(e) => setUnit(e.target.value)}>
                  {["serving", "cup", "g", "oz", "tbsp", "tsp", "piece", "slice", "ml"].map((u) => (
                    <option key={u}>{u}</option>
                  ))}
                </select>
              </div>
            </div>
            <button className="btn btn-primary" style={{ width: "100%" }} onClick={() => analyze()} disabled={loading || !foodItem.trim()}>
              {loading ? "Analyzing…" : "Analyze Nutrition"}
            </button>
          </div>

          <div style={{ marginTop: 20 }}>
            <p className="form-label" style={{ marginBottom: 10 }}>Try These Examples</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {EXAMPLE_FOODS.map((f) => (
                <button key={f} className="quick-q" onClick={() => { setFoodItem(f); analyze(f); }}>
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Panel */}
        <div>
          {error && <div className="error-msg">⚠️ {error}</div>}
          {loading && (
            <div className="loading">
              <div className="spinner" />
              Analyzing nutritional content with Gemini AI...
            </div>
          )}
          {result && (
            <div className="card nutrition-result">
              <div className="result-header">
                <div>
                  <p className="form-label" style={{ marginBottom: 4 }}>Nutritional Profile</p>
                  <h2 className="food-name">{result.foodItem}</h2>
                  <p style={{ fontSize: 13, color: "#5a6672" }}>{result.quantity}</p>
                </div>
                <div>
                  <div className="calorie-badge">🔥 {result.calories} kcal</div>
                </div>
              </div>

              {/* Health Score */}
              <div className="health-score-ring">
                <div className="score-circle" style={{ borderColor: scoreColor(result.healthScore) }}>
                  <span className="score-num" style={{ color: scoreColor(result.healthScore) }}>{result.healthScore}</span>
                  <span className="score-label">Health</span>
                </div>
                <p style={{ fontSize: 14, color: "#5a6672", lineHeight: 1.5 }}>{result.summary}</p>
              </div>

              {/* Macros */}
              <h3 className="section-title">Macronutrients</h3>
              <div className="macros-grid">
                {["protein", "carbohydrates", "fat"].map((key) => {
                  const m = result.macronutrients?.[key];
                  return (
                    <div className="macro-card" key={key}>
                      <div className="macro-value">{m?.amount ?? "—"}</div>
                      <div className="macro-unit">{m?.unit}</div>
                      <div className="macro-name">{key.charAt(0).toUpperCase() + key.slice(1)}</div>
                      <div className="macro-dv">{m?.dailyValue}% DV</div>
                    </div>
                  );
                })}
              </div>

              {/* Progress Bars for other macros */}
              {["fiber", "sugar"].map((key) => {
                const m = result.macronutrients?.[key];
                if (!m) return null;
                return (
                  <div className="progress-bar-wrap" key={key}>
                    <div className="progress-label">
                      <span style={{ textTransform: "capitalize" }}>{key}</span>
                      <span>{m.amount}{m.unit} ({m.dailyValue}% DV)</span>
                    </div>
                    <div className="progress-track">
                      <div className="progress-fill" style={{ width: `${Math.min(m.dailyValue, 100)}%` }} />
                    </div>
                  </div>
                );
              })}

              {/* Micronutrients */}
              {result.micronutrients && (
                <>
                  <h3 className="section-title" style={{ marginTop: 24 }}>Micronutrients</h3>
                  <div className="micro-grid">
                    {[...(result.micronutrients.vitamins || []), ...(result.micronutrients.minerals || [])].slice(0, 10).map((m, i) => (
                      <div className="micro-item" key={i}>
                        <span className="micro-name">{m.name}</span>
                        <span className="micro-val">{m.amount}{m.unit}</span>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {/* Benefits */}
              {result.healthBenefits?.length > 0 && (
                <>
                  <h3 className="section-title" style={{ marginTop: 24 }}>Health Benefits</h3>
                  <ul className="benefits-list">
                    {result.healthBenefits.map((b, i) => <li key={i}>{b}</li>)}
                  </ul>
                </>
              )}

              {/* Warnings */}
              {result.warnings?.length > 0 && (
                <div style={{ marginTop: 16, background: "#fff5f5", borderRadius: 10, padding: "12px 16px" }}>
                  {result.warnings.map((w, i) => (
                    <p key={i} style={{ fontSize: 13, color: "#e53e3e", marginBottom: 4 }}>⚠️ {w}</p>
                  ))}
                </div>
              )}
            </div>
          )}
          {!result && !loading && !error && (
            <div style={{ textAlign: "center", padding: "60px 20px", color: "#9eb8aa" }}>
              <div style={{ fontSize: 64, marginBottom: 16 }}>🥗</div>
              <p style={{ fontSize: 16 }}>Enter a food item to see its nutritional breakdown</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
