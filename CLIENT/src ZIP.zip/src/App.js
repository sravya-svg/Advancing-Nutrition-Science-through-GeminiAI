import React, { useState } from "react";
import NutritionAnalyzer from "./components/NutritionAnalyzer";
import MealPlanner from "./components/MealPlanner";
import NutritionCoach from "./components/NutritionCoach";
import FoodComparison from "./components/FoodComparison";
import "./App.css";

const NAV_ITEMS = [
  { id: "analyzer", label: "Nutrition Analyzer", icon: "🔬" },
  { id: "planner", label: "Meal Planner", icon: "📅" },
  { id: "coach", label: "AI Coach", icon: "🤖" },
  { id: "compare", label: "Compare Foods", icon: "⚖️" },
];

export default function App() {
  const [activeTab, setActiveTab] = useState("analyzer");

  return (
    <div className="app">
      <header className="header">
        <div className="header-inner">
          <div className="logo">
            <span className="logo-icon">🌿</span>
            <div>
              <span className="logo-name">NutriGen</span>
              <span className="logo-sub">Powered by Gemini AI</span>
            </div>
          </div>
          <nav className="nav">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                className={`nav-btn ${activeTab === item.id ? "active" : ""}`}
                onClick={() => setActiveTab(item.id)}
              >
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="main">
        {activeTab === "analyzer" && <NutritionAnalyzer />}
        {activeTab === "planner" && <MealPlanner />}
        {activeTab === "coach" && <NutritionCoach />}
        {activeTab === "compare" && <FoodComparison />}
      </main>

      <footer className="footer">
        <p>NutriGen © 2024 • Powered by Google Gemini AI • Not a substitute for professional medical advice</p>
      </footer>
    </div>
  );
}
